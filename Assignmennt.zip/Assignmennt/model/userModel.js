class User {
  constructor(
    firstName,
    lastName,
    gender,
    dateOfBirth,
    email,
    password,
    profileImage
  ) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.gender = gender;
    this.dateOfBirth = dateOfBirth;
    this.email = email;
    this.password = password;
    this.profileImage = profileImage;
  }
}

module.exports = User;
