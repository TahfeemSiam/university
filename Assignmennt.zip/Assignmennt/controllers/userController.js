const connection = require("./../database");
const bcrypt = require("bcrypt");
const User = require("./../model/userModel");
const jwt = require("jsonwebtoken");
const path = require("path");

function generateToken(userId) {
  return jwt.sign(
    {
      data: userId,
    },
    "secret",
    { expiresIn: 60 * 60 * 24 * 1 }
  );
}

exports.imageUpload = (req, res) => {
  const query = "UPDATE user SET profileImage = ? WHERE user_id = ?";

  connection.query(
    query,
    [req.file.filename, req.params.id],
    (error, result) => {
      res.redirect("/dashboard");
    }
  );
};

exports.userRegistration = (req, res) => {
  const user = new User(
    req.body.firstName,
    req.body.lastName,
    req.body.gender,
    req.body.dateOfBirth,
    req.body.email,
    req.body.password,
    req.body.profileImage
  );

  const saltRounds = 10;

  let query =
    "INSERT INTO user(firstName, lastName, gender, dateOfBirth, email, password, profileImage)";
  query += " VALUES(?, ?, ?, ?, ?, ?, ?)";

  bcrypt.hash(user.password, saltRounds).then(function (hash) {
    // Store hash in your password DB.
    connection.query(
      query,
      [
        user.firstName,
        user.lastName,
        user.gender,
        user.dateOfBirth,
        user.email,
        hash,
        "stock-vector-profile-picture-avatar-icon-vector-1760295569.jpg",
      ],
      (error, result) => {
        res.status(201).json({
          message: "User Registered Successfully",
          data: result,
        });
      }
    );
  });
};

exports.userLogin = (req, res, next) => {
  const query = "SELECT user_id, email, password FROM user WHERE email = ?";

  let user = [];

  connection.query(query, [req.body.email], (error, result) => {
    if (error) {
      console.log(error);
    } else {
      user = result;
      bcrypt.compare(
        req.body.password,
        user[0].password,
        function (err, correct) {
          const token = generateToken(user[0].user_id);
          const decoded = jwt.verify(token, "secret");
          if (correct && decoded) {
            req.token = token;
            req.id = user[0].user_id;
            req.loggedIn = correct;
            next();
          } else if (!correct) {
            return res.status(404).json({
              message: "Invalid Password",
            });
          } else {
            return res.status(401).json({
              message: "Not Authorized",
            });
          }
        }
      );
    }
  });
};

exports.redirectToDashboard = (req, res) => {
  if (req.loggedIn) {
    res.cookie("jwt", String(req.token), {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 100,
    });

    res.cookie("id", req.id, {
      httpOnly: false,
      maxAge: 60 * 60 * 24 * 100,
    });

    res.status(200).json({
      message: "Logged In",
      token: req.token,
    });
  }
};

exports.logout = (req, res) => {
  if (req.authenticated) {
    res.clearCookie("jwt");
    res.clearCookie("id");
    res.redirect("/");
  }
};

exports.checkIfAuthenticated = (req, res, next) => {
  let checkCookie = req.headers.cookie == undefined ? "" : req.cookies.jwt;

  if (checkCookie === "" || !req.cookies.jwt) {
    req.authenticated = false;
    next();
  } else {
    req.authenticated = true;
    next();
  }
};

exports.getUserProfile = (req, res) => {
  const query = "SELECT * FROM user WHERE user_id = ?";

  connection.query(query, [req.params.id], (error, result) => {
    res.status(200).json({
      message: "Fetched User Data",
      data: result,
    });
  });
};

exports.deleteUser = (req, res) => {
  const query = "DELETE FROM user WHERE user_id = ?";

  connection.query(query, [req.params.id], (error, result) => {
    res.clearCookie("jwt");
    res.clearCookie("id");
    res.status(202).json({
      message: "User Deleted",
    });
  });
};

exports.updateUser = (req, res) => {
  const query =
    "UPDATE user SET firstName = ?, lastName = ?, email = ? WHERE user_id = ?";

  connection.query(
    query,
    [req.body.firstName, req.body.lastName, req.body.email, req.params.id],
    (error, result) => {
      res.status(200).json({
        message: "User Updated",
      });
    }
  );
};

exports.dashboardRoute = (req, res) => {
  if (!req.authenticated) {
    res.redirect("/");
  } else {
    res.sendFile(path.join(__dirname, "../views/dashboard.html"));
  }
};

exports.loginRoute = (req, res) => {
  if (!req.authenticated) {
    res.sendFile(path.join(__dirname, "../views/login.html"));
  } else {
    res.redirect("/dashboard");
  }
};

exports.registerRoute = (req, res) => {
  if (!req.authenticated) {
    res.sendFile(path.join(__dirname, "../views/register.html"));
  } else {
    res.redirect("/dashboard");
  }
};
