📋 #----- This file contains all the info related to this project -----#

# 📚 The files and folder are structed using the mvc pattern

1️⃣ About index.js and database.js

# index.js contains few global middlewares to read and parse cookies recieved from each and every request sent by the client and also few express middlewares to read static files from the views .

2️⃣ About the views and uploads folder

# This folder contains all the static html, css and js files which are used to render contents on the server and the uploads folder conatins all the images uploaded from the server which are also used as part of the contents on the frontend.

3️⃣ About the routers folder

# This folder contains all of the route configurations for various http requests which includes both the route endpoints and the middlewares used to protect some of the routes.

4️⃣ About the controllers folder

# This folder contains all of the functions for each and every api requests which includes functions for userRegistration, userLogin, userLogout, pageRoutes and all of the functions for CRUD operations.

❎ **\*** Few Key Points regarding user authentication and page routing **\***

# In this project userAuthentication has been done using jsonWebtokens and also the users passwords are hashed using bcrypt so both of these npm packages are used for userAuthentication and also some the page route access are blocked if the user is not authenticated so all of this data are stored in the cookie which is later on cleared if the user logs out before the cookies have expired.

🔽 #API ENDOINTS 🔽

# ✅ For image upload: "/api/profile/image/:id" (Requires the user to be logged in)

# ✅ For user registration: "/api/register"

# ✅ For user login: "/api/login"

# ✅ For user CRUD operations: "/api/profile/:id" (Except read all of the operations requires the user to be logged in)

# ✅ login page route: "/"

# ✅ register page route: "/register"

# ✅ dashboard page route: "/dashboard" (Requires the user to be logged in)
