const express = require("express");
const server = express();
const cookieParser = require("cookie-parser");
const userRouter = require("./routers/userRouter");
server.use(express.json());
server.use(cookieParser());

server.use(express.static("uploads"));
server.use(express.static("views"));

server.use((req, res, next) => {
  console.log(req.cookies);
  next();
});

server.use("/", userRouter);

server.listen(5000, function () {
  console.log("Server Running");
});
