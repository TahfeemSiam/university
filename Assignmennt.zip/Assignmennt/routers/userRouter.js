const express = require("express");
const multer = require("multer");
const userRouter = express.Router();
const userController = require("./../controllers/userController");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(
      null,
      file.fieldname + "-" + uniqueSuffix + "." + file.mimetype.split("/")[1]
    );
  },
});

const upload = multer({ storage });

userRouter
  .route("/api/profile/image/:id")
  .post(
    userController.checkIfAuthenticated,
    upload.single("uploaded_image"),
    userController.imageUpload
  );

userRouter.route("/api/register").post(userController.userRegistration);
userRouter
  .route("/api/login")
  .post(userController.userLogin, userController.redirectToDashboard);

userRouter
  .route("/api/profile/:id")
  .get(userController.getUserProfile)
  .delete(userController.checkIfAuthenticated, userController.deleteUser)
  .patch(userController.checkIfAuthenticated, userController.updateUser);

// Page Routes
userRouter.get(
  "/dashboard",
  userController.checkIfAuthenticated,
  userController.dashboardRoute
);
userRouter.get(
  "/",
  userController.checkIfAuthenticated,
  userController.loginRoute
);
userRouter.get(
  "/register",
  userController.checkIfAuthenticated,
  userController.registerRoute
);

userRouter.get(
  "/logout",
  userController.checkIfAuthenticated,
  userController.logout
);

module.exports = userRouter;
