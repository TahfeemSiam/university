const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  database: "assignment",
  user: "root",
  password: "",
});

module.exports = connection;
