const fname = document.getElementById("fname");
const lname = document.getElementById("lname");
const gender = document.getElementById("gender");
const dob = document.getElementById("date");
const email = document.getElementById("email");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("rpassword");
const form = document.querySelector(".form");

const warning = document.querySelector(".warning");
const incorrectPassword = document.querySelector(".incorrect-password");
const success = document.querySelector(".success");

form.addEventListener("submit", function (e) {
  e.preventDefault();
  const user = {
    firstName: fname.value,
    lastName: lname.value,
    gender: gender.value,
    dateOfBirth: dob.value,
    email: email.value,
    password: password.value,
    profileImage:
      "stock-vector-profile-picture-avatar-icon-vector-1760295569.jpg",
  };

  if (
    !user.firstName ||
    !user.lastName ||
    !user.gender ||
    !user.dateOfBirth ||
    !user.email ||
    !user.password ||
    !confirmPassword.value
  ) {
    warning.classList.remove("display");
    incorrectPassword.classList.add("display");
  } else if (user.password !== confirmPassword.value) {
    warning.classList.add("display");
    incorrectPassword.classList.remove("display");
  } else {
    fetch("http://localhost:5000/api/register", {
      method: "post",
      body: JSON.stringify(user),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        warning.classList.add("display");
        incorrectPassword.classList.add("display");
        success.classList.remove("display");
        setTimeout(function () {
          window.location.replace("/");
        }, 1000);
      })
      .catch((error) => {
        console.log(error);
      });
  }
});
