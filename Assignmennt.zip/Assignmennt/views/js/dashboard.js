const adminNav = document.querySelector(".admin-nav");
let firstName = document.getElementById("firstName");
let lastName = document.getElementById("lastName");
let email = document.getElementById("email");
let imageUploadForm = document.querySelector(".image-upload");
let image = document.getElementById("image");
let usersData = [];
let cookieValue = document.cookie;
let id = Number(cookieValue.split("=")[1]);
function fetchUsersData() {
  fetch(`http://localhost:5000/api/profile/${id}`)
    .then((response) => response.json())
    .then((res) => {
      usersData = res.data;

      for (let i = 0; i < usersData.length; i++) {
        adminNav.insertAdjacentHTML(
          "afterend",
          `
                <div class="container d-flex justify-content-center">
                    <div class="card profile">
                      <img
                        src="${usersData[i].profileImage}"
                        class="card-img-top"
                        alt="Fissure in Sandstone"
                      />
                      <div class="card-body">
                        <h5 class="card-title">${usersData[i].firstName} ${usersData[i].lastName}</h5>
                        <p class="card-text">Gender: ${usersData[i].gender}</p>
                        <p class="card-text">Email: ${usersData[i].email}</p>
                        <p class="card-text">Date Of Birth: ${usersData[i].dateOfBirth}</p>
                        <div
                          class="modal fade"
                          id="exampleModal"
                          tabindex="-1"
                          aria-labelledby="exampleModalLabel"
                          aria-hidden="true"
                        >
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update User Data</h5>
                                <button
                                  type="button"
                                  class="btn-close"
                                  data-mdb-ripple-init
                                  data-mdb-dismiss="modal"
                                  aria-label="Close"
                                ></button>
                              </div>
                              <div class="modal-body">
                                  <input
                                    class="form-control firstName"
                                    value="${usersData[i].firstName}"
                                    type="text"
                                  />
                                  <input
                                    class="form-control lastName"
                                    value="${usersData[i].lastName}"
                                    type="text"
                                  />
                                  <input
                                    class="form-control email"
                                    value="${usersData[i].email}"
                                    type="text"
                                  />
                                  <br />
                                  <button onclick="updateUser(${usersData[i].user_id})" class="btn btn-primary"
                                  data-mdb-ripple-init>Update</button>
                              </div>
                              <div class="modal-footer">
                                <button
                                  type="button"
                                  class="btn btn-secondary"
                                  data-mdb-ripple-init
                                  data-mdb-dismiss="modal"
                                >
                                  Close
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="d-flex justify-content-between">
                          <button
                            type="button"
                            class="btn btn-primary"
                            data-mdb-ripple-init
                            data-mdb-modal-init
                            data-mdb-target="#exampleModal"
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            class="btn btn-success"
                            data-mdb-ripple-init
                            data-mdb-modal-init
                            data-mdb-target="#exampleModal2"
                          >
                            Upload Image
                          </button>

                          <button
                            onclick="deleteUser(${usersData[i].user_id})"
                            type="button"
                            class="btn btn-info"
                            data-mdb-ripple-init
                          >
                            Delete Profile
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                `
        );
      }
    });
}

fetchUsersData();

function deleteUser(id) {
  fetch(`http://localhost:5000/api/profile/${id}`, {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      return response.json();
    })
    .then((res) => {
      alert("Profile Deleted");
      location.replace("/register");
    })
    .catch((error) => {
      console.log(error);
    });
}

function updateUser(id) {
  fetch(`http://localhost:5000/api/profile/updateUser/${id}`, {
    method: "PATCH",
    body: JSON.stringify({
      firstName: firstName.value,
      lastName: lastName.value,
      email: email.value,
    }),
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      return response.json();
    })
    .then((res) => {
      console.log(res);
    })
    .catch((error) => {
      console.log(error);
    });
}

imageUploadForm.addEventListener("submit", function (e) {
  alert("image Uploaded");
});

function setFromAction() {
  imageUploadForm.action = `http://localhost:5000/api/profile/image/${id}`;
  console.log(imageUploadForm);
  console.log(imageUploadForm.action);
}

setFromAction();
