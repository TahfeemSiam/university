const email = document.getElementById("email");
const password = document.getElementById("password");
const form = document.querySelector(".form");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const user = {
    email: email.value,
    password: password.value,
  };

  fetch("http://localhost:5000/api/login", {
    method: "post",
    body: JSON.stringify(user),
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      return response.json();
    })
    .then((res) => {
      if (res.message == "Invalid Password") {
        window.location.replace("/login");
      } else {
        window.location.replace("/dashboard");
        console.log(res);
      }
    })
    .catch((error) => {
      console.log(error);
    });
});
